package com.example.sunshine;

public interface FragmentCallbacks {
    public void fromMainToFragment(Object request);
}
