package com.example.sunshine;

public interface MainCallbacks {
    public void fromFragmentToMain(String sender, String request, Object value);
}
